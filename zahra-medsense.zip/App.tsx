import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  AppStep, 
  Language, 
  TEXTS, 
  AnalysisResult 
} from './types';
import { analyzeAssessment } from './services/geminiService';
import { 
  VideoCameraIcon, 
  MicrophoneIcon, 
  CheckCircleIcon, 
  ExclamationTriangleIcon,
  XCircleIcon,
  PlayIcon,
  StopIcon,
  ArrowPathIcon,
  HandRaisedIcon
} from '@heroicons/react/24/solid';

// Simple Waveform Animation Component
const Waveform = () => (
  <div className="flex items-center justify-center space-x-1 h-8">
    {[...Array(5)].map((_, i) => (
      <div
        key={i}
        className="w-1 bg-teal-400 rounded-full animate-pulse"
        style={{
          height: `${Math.random() * 100}%`,
          animationDuration: `${0.5 + Math.random() * 0.5}s`
        }}
      />
    ))}
  </div>
);

const MAX_RECORDING_TIME_MS = 10000; // 10 seconds limit to avoid large payloads

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.ONBOARDING);
  const [language, setLanguage] = useState<Language>(Language.EN);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  const content = TEXTS[language];

  // --- Handlers ---
  
  const getSupportedMimeType = () => {
    const types = [
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4'
    ];
    return types.find(type => MediaRecorder.isTypeSupported(type));
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, 
        audio: true 
      });
      
      setMediaStream(stream);

      const mimeType = getSupportedMimeType();
      if (!mimeType) {
        alert("Your browser does not support video recording.");
        return;
      }

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: mimeType,
        videoBitsPerSecond: 1000000 // 1Mbps limit to keep size down
      });

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        setRecordedBlob(blob);
        chunksRef.current = [];
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
        setMediaStream(null);
        
        handleAnalyze(blob);
      };

      mediaRecorderRef.current = mediaRecorder;
      setStep(AppStep.RECORDING);
    } catch (err) {
      console.error("Error accessing media devices:", err);
      alert("Camera/Microphone permission denied. Please allow access in your browser settings.");
    }
  };

  // Effect to attach stream to video element once it is rendered
  useEffect(() => {
    if (videoRef.current && mediaStream) {
      videoRef.current.srcObject = mediaStream;
    }
  }, [step, mediaStream]);

  const startRecording = () => {
    setCountdown(3);
  };

  useEffect(() => {
    if (countdown === null) return;
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
    if (countdown === 0) {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'inactive') {
        mediaRecorderRef.current.start();
        setIsRecording(true);
        setRecordingTime(MAX_RECORDING_TIME_MS / 1000);
        
        // Auto stop after max time
        recordingTimerRef.current = window.setTimeout(() => {
          stopRecording();
        }, MAX_RECORDING_TIME_MS);
      }
      setCountdown(null);
    }
  }, [countdown]);

  // Visual countdown for recording time
  useEffect(() => {
    if (!isRecording || recordingTime <= 0) return;
    const interval = setInterval(() => {
      setRecordingTime(t => t - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRecording, recordingTime]);

  const stopRecording = useCallback(() => {
    if (recordingTimerRef.current) {
      clearTimeout(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setStep(AppStep.ANALYZING);
    }
  }, []);

  const handleAnalyze = async (blob: Blob) => {
    const result = await analyzeAssessment(blob, language);
    setAnalysisResult(result);
    setStep(AppStep.RESULTS);
  };

  const resetApp = () => {
    setStep(AppStep.ONBOARDING);
    setRecordedBlob(null);
    setAnalysisResult(null);
    setMediaStream(null);
    setRecordingTime(0);
  };

  // --- Render Steps ---

  const renderOnboarding = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center animate-fade-in">
      <div className="mb-8 p-4 rounded-full bg-teal-500/10 border border-teal-500/30 shadow-[0_0_30px_rgba(20,184,166,0.2)]">
        <div className="text-4xl font-bold text-teal-400 tracking-widest">Z.A.H.R.A</div>
      </div>
      <h1 className="text-xl md:text-2xl font-light text-slate-300 mb-2">Zenith AI for Health & Recovery Analysis</h1>
      <p className="text-sm text-slate-500 mb-10 max-w-md">Gemini-Powered Neurological Screening</p>

      <div className="grid grid-cols-3 gap-4 mb-12 w-full max-w-sm">
        {Object.values(Language).map((lang) => (
          <button
            key={lang}
            onClick={() => setLanguage(lang)}
            className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all duration-300 ${
              language === lang
                ? 'bg-teal-500 text-white shadow-lg scale-105'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            {lang}
          </button>
        ))}
      </div>

      <div className="bg-slate-800/50 backdrop-blur-md p-8 rounded-3xl border border-slate-700 w-full max-w-md shadow-2xl">
        <h2 className="text-2xl font-bold text-white mb-2">{content.welcome}</h2>
        <p className="text-slate-400 mb-8">{content.tagline}</p>
        <button
          onClick={() => setStep(AppStep.INSTRUCTIONS)}
          className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold py-4 rounded-xl shadow-lg shadow-teal-500/20 transition-all transform hover:scale-[1.02] active:scale-95"
        >
          {content.startBtn}
        </button>
      </div>
    </div>
  );

  const renderInstructions = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 md:p-6 animate-fade-in">
      <div className="w-full max-w-lg bg-slate-800/90 backdrop-blur-xl p-8 rounded-3xl border border-slate-700 shadow-2xl">
        <h2 className="text-2xl font-bold text-white text-center mb-6 border-b border-slate-700 pb-4">
          {content.instructionsTitle}
        </h2>

        <div className="space-y-6 mb-8">
          {/* Step 1: Prep */}
          <div className="flex items-start space-x-4">
            <div className="bg-slate-700 p-2 rounded-lg text-teal-400 flex-shrink-0">
               <VideoCameraIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-teal-400 font-bold text-sm uppercase tracking-wide mb-1">{content.step1Title}</h3>
              <p className="text-slate-300 text-sm leading-relaxed">{content.step1Body}</p>
            </div>
          </div>

          {/* Step 2: Motor */}
          <div className="flex items-start space-x-4">
            <div className="bg-slate-700 p-2 rounded-lg text-blue-400 flex-shrink-0">
               <HandRaisedIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-blue-400 font-bold text-sm uppercase tracking-wide mb-1">{content.step2Title}</h3>
              <p className="text-slate-300 text-sm leading-relaxed">{content.step2Body}</p>
            </div>
          </div>

          {/* Step 3: Speech */}
          <div className="flex items-start space-x-4">
            <div className="bg-slate-700 p-2 rounded-lg text-purple-400 flex-shrink-0">
               <MicrophoneIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-purple-400 font-bold text-sm uppercase tracking-wide mb-1">{content.step3Title}</h3>
              <p className="text-slate-300 text-sm leading-relaxed mb-2">{content.step3Body}</p>
              <div className="bg-purple-900/30 border-l-4 border-purple-500 p-3 rounded-r-lg">
                <p className="text-white italic text-sm font-medium">
                  {content.speechPhrase}
                </p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={startCamera}
          className="w-full bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-500 hover:to-blue-500 text-white font-bold py-4 rounded-xl shadow-lg transition-all transform hover:scale-[1.01]"
        >
          {content.recordBtn}
        </button>
        <button 
           onClick={() => setStep(AppStep.ONBOARDING)}
           className="w-full mt-4 text-slate-500 hover:text-white text-sm transition-colors"
        >
            Back
        </button>
      </div>
    </div>
  );

  const renderRecording = () => (
    <div className="flex flex-col items-center min-h-screen bg-black relative">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover absolute inset-0 z-0 opacity-80"
      />
      
      {/* Overlay UI */}
      <div className="absolute inset-0 z-10 flex flex-col justify-between p-6 bg-gradient-to-b from-black/60 via-transparent to-black/80">
        <div className="flex justify-between items-center">
            <span className="text-teal-400 font-mono text-sm tracking-wider border border-teal-500/50 px-3 py-1 rounded-full bg-teal-900/30 backdrop-blur-md">
                LIVE ANALYSIS
            </span>
            <div className="flex items-center space-x-2 text-white/80 text-xs bg-black/40 px-3 py-1 rounded-full backdrop-blur-md">
               <MicrophoneIcon className="w-3 h-3" />
               <span>AUDIO ON</span>
            </div>
        </div>

        <div className="flex flex-col items-center w-full max-w-md mx-auto">
          {countdown !== null && (
             <div className="text-9xl font-bold text-white animate-ping mb-20 drop-shadow-lg">
               {countdown > 0 ? countdown : "GO"}
             </div>
          )}

          {!isRecording && countdown === null && (
             <button
               onClick={startRecording}
               className="mb-10 w-20 h-20 rounded-full bg-red-600 border-4 border-slate-200 flex items-center justify-center hover:scale-110 transition-transform shadow-[0_0_20px_rgba(220,38,38,0.6)]"
             >
                <div className="w-8 h-8 bg-white rounded-full"></div>
             </button>
          )}

          {isRecording && (
             <div className="w-full flex flex-col items-center mb-10">
                <div className="text-white font-bold text-lg mb-2 drop-shadow-md">
                   {recordingTime}s remaining
                </div>
                {/* Visual Cue for current task based on time remaining */}
                <div className="mb-4 px-4 py-2 bg-black/60 rounded-lg text-center backdrop-blur-md border border-white/10">
                  {recordingTime > 5 ? (
                     <div className="text-blue-300 font-semibold animate-pulse">
                        TAP FINGERS
                     </div>
                  ) : (
                     <div className="text-purple-300 font-semibold animate-pulse">
                        SPEAK NOW
                     </div>
                  )}
                </div>

                <div className="mb-4 bg-black/50 backdrop-blur px-6 py-2 rounded-full border border-white/10">
                   <Waveform />
                </div>
                <button
                  onClick={stopRecording}
                  className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-4 rounded-xl flex items-center justify-center space-x-2 shadow-lg transition-all"
                >
                  <StopIcon className="w-6 h-6" />
                  <span>{content.stopBtn}</span>
                </button>
             </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderAnalyzing = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-slate-900">
       <div className="relative w-32 h-32 mb-8">
          <div className="absolute inset-0 border-4 border-teal-500/30 rounded-full animate-ping"></div>
          <div className="absolute inset-0 border-4 border-t-teal-500 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-16 h-16 bg-teal-500 rounded-full animate-pulse shadow-[0_0_40px_rgba(20,184,166,0.6)]"></div>
          </div>
       </div>
       <h2 className="text-2xl font-bold text-white text-center mb-2 animate-pulse">Processing Data</h2>
       <p className="text-slate-400 text-center max-w-xs">{content.analyzing}</p>
    </div>
  );

  const renderResults = () => {
    if (!analysisResult) return null;

    const { status_color, overall_risk_score, motoric_scores, summary, recommendation } = analysisResult;
    
    const colorMap = {
      'Green': 'bg-emerald-500 shadow-emerald-500/40 text-emerald-50',
      'Yellow': 'bg-yellow-500 shadow-yellow-500/40 text-yellow-900',
      'Red': 'bg-red-500 shadow-red-500/40 text-white'
    };

    const borderColorMap = {
      'Green': 'border-emerald-500',
      'Yellow': 'border-yellow-500',
      'Red': 'border-red-500'
    };

    return (
      <div className="flex flex-col items-center min-h-screen p-4 md:p-8 bg-slate-950 animate-fade-in-up">
        <header className="w-full max-w-2xl flex justify-between items-center mb-6">
           <h1 className="text-teal-500 font-bold tracking-widest text-lg">Z.A.H.R.A REPORT</h1>
           <button onClick={resetApp} className="text-slate-500 hover:text-white">
              <ArrowPathIcon className="w-6 h-6" />
           </button>
        </header>

        <div className="w-full max-w-2xl space-y-4">
          
          {/* Main Status Card */}
          <div className={`relative overflow-hidden rounded-3xl p-6 ${colorMap[status_color]} shadow-2xl`}>
             <div className="absolute top-0 right-0 p-4 opacity-20">
                {status_color === 'Green' ? <CheckCircleIcon className="w-32 h-32" /> :
                 status_color === 'Yellow' ? <ExclamationTriangleIcon className="w-32 h-32" /> :
                 <XCircleIcon className="w-32 h-32" />}
             </div>
             
             <div className="relative z-10">
               <div className="text-sm font-bold uppercase opacity-80 mb-1">{content.riskScore}</div>
               <div className="text-6xl font-black mb-4">{overall_risk_score}<span className="text-2xl opacity-60">/10</span></div>
               <div className="text-lg font-medium leading-tight max-w-xs">{summary}</div>
             </div>
          </div>

          {/* Detailed Scores */}
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                <div className="text-slate-400 text-xs uppercase mb-1">Finger Tapping</div>
                <div className="text-2xl font-bold text-white">{motoric_scores.finger_tapping}<span className="text-sm text-slate-600">/4</span></div>
                <div className="w-full bg-slate-800 h-1 mt-2 rounded-full overflow-hidden">
                   <div className="bg-blue-500 h-full transition-all duration-1000" style={{width: `${(motoric_scores.finger_tapping/4)*100}%`}}></div>
                </div>
             </div>
             <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                <div className="text-slate-400 text-xs uppercase mb-1">Tremor</div>
                <div className="text-2xl font-bold text-white">{motoric_scores.tremor}<span className="text-sm text-slate-600">/4</span></div>
                 <div className="w-full bg-slate-800 h-1 mt-2 rounded-full overflow-hidden">
                   <div className="bg-purple-500 h-full transition-all duration-1000" style={{width: `${(motoric_scores.tremor/4)*100}%`}}></div>
                </div>
             </div>
             <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                <div className="text-slate-400 text-xs uppercase mb-1">Hand Movement</div>
                <div className="text-2xl font-bold text-white">{motoric_scores.hand_movements}<span className="text-sm text-slate-600">/4</span></div>
                 <div className="w-full bg-slate-800 h-1 mt-2 rounded-full overflow-hidden">
                   <div className="bg-orange-500 h-full transition-all duration-1000" style={{width: `${(motoric_scores.hand_movements/4)*100}%`}}></div>
                </div>
             </div>
             <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                <div className="text-slate-400 text-xs uppercase mb-1">Facial Symmetry</div>
                <div className="text-2xl font-bold text-white">{motoric_scores.facial_symmetry}<span className="text-sm text-slate-600">/4</span></div>
                 <div className="w-full bg-slate-800 h-1 mt-2 rounded-full overflow-hidden">
                   <div className="bg-pink-500 h-full transition-all duration-1000" style={{width: `${(motoric_scores.facial_symmetry/4)*100}%`}}></div>
                </div>
             </div>
          </div>

          {/* Recommendation */}
          <div className={`bg-slate-900 p-6 rounded-3xl border ${borderColorMap[status_color]} border-opacity-50`}>
             <h3 className="text-slate-300 font-bold mb-2 uppercase text-xs tracking-wider">{content.recommendation}</h3>
             <p className="text-white text-md leading-relaxed">{recommendation}</p>
             {overall_risk_score > 3 && (
               <div className="mt-4 p-3 bg-red-900/30 border border-red-900/50 rounded-lg flex items-start space-x-2">
                 <ExclamationTriangleIcon className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                 <span className="text-sm text-red-200">{content.consultDoctor}</span>
               </div>
             )}
          </div>

          <button
            onClick={resetApp}
            className="w-full py-4 text-slate-400 hover:text-white font-medium transition-colors"
          >
            Start New Assessment
          </button>

        </div>
      </div>
    );
  };

  return (
    <>
      {step === AppStep.ONBOARDING && renderOnboarding()}
      {step === AppStep.INSTRUCTIONS && renderInstructions()}
      {step === AppStep.RECORDING && renderRecording()}
      {step === AppStep.ANALYZING && renderAnalyzing()}
      {step === AppStep.RESULTS && renderResults()}
    </>
  );
};

export default App;