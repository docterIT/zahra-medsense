export enum AppStep {
  ONBOARDING = 'ONBOARDING',
  INSTRUCTIONS = 'INSTRUCTIONS',
  RECORDING = 'RECORDING',
  ANALYZING = 'ANALYZING',
  RESULTS = 'RESULTS'
}

export enum Language {
  EN = 'English',
  ID = 'Indonesia',
  AR = 'العربية'
}

export interface MotoricScores {
  finger_tapping: number;
  hand_movements: number;
  facial_symmetry: number;
  tremor: number;
}

export interface AnalysisResult {
  overall_risk_score: number;
  status_color: 'Green' | 'Yellow' | 'Red';
  motoric_scores: MotoricScores;
  acoustic_analysis: string;
  recommendation: string;
  summary: string; // The human readable summary requested
}

export interface LanguageContent {
  welcome: string;
  tagline: string;
  startBtn: string;
  instructionsTitle: string;
  // New specific instruction fields
  step1Title: string;
  step1Body: string;
  step2Title: string;
  step2Body: string;
  step3Title: string;
  step3Body: string;
  speechPhrase: string; // The specific phrase to read
  
  recordBtn: string;
  stopBtn: string;
  analyzing: string;
  resultsTitle: string;
  riskScore: string;
  recommendation: string;
  consultDoctor: string;
}

export const TEXTS: Record<Language, LanguageContent> = {
  [Language.EN]: {
    welcome: "Welcome to Z.A.H.R.A",
    tagline: "Neurological screening at your fingertips.",
    startBtn: "Start Assessment",
    instructionsTitle: "Assessment Protocol",
    
    step1Title: "Preparation",
    step1Body: "Ensure you are in a well-lit room. Position your phone at eye level so your face and hands are clearly visible.",
    
    step2Title: "00:00 - 00:05 : Motor Task",
    step2Body: "Raise both hands. Tap your thumb and index finger together rapidly and widely.",
    
    step3Title: "00:05 - 00:10 : Speech Task",
    step3Body: "Stop tapping and say the following phrase clearly and loudly:",
    speechPhrase: "\"The quick brown fox jumps over the lazy dog.\"",

    recordBtn: "I Understand, Start Recording",
    stopBtn: "Stop & Analyze",
    analyzing: "Z.A.H.R.A is analyzing kinematic and acoustic biomarkers...",
    resultsTitle: "Assessment Report",
    riskScore: "Risk Score",
    recommendation: "Recommendation",
    consultDoctor: "Consult a neurologist immediately."
  },
  [Language.ID]: {
    welcome: "Selamat Datang di Z.A.H.R.A",
    tagline: "Skrining neurologis dalam genggaman Anda.",
    startBtn: "Mulai Pemeriksaan",
    instructionsTitle: "Protokol Pemeriksaan",

    step1Title: "Persiapan",
    step1Body: "Pastikan ruangan terang. Posisikan HP sejajar mata agar wajah dan kedua tangan terlihat jelas di layar.",

    step2Title: "00:00 - 00:05 : Tes Motorik",
    step2Body: "Angkat kedua tangan. Ketukkan jari telunjuk dan jempol anda secara cepat dan lebar berulang kali.",

    step3Title: "00:05 - 00:10 : Tes Suara",
    step3Body: "Berhenti mengetuk, lalu ucapkan kalimat di bawah ini dengan lantang dan jelas:",
    speechPhrase: "\"Langit berwarna biru dan matahari bersinar cerah hari ini.\"",

    recordBtn: "Saya Paham, Mulai Rekam",
    stopBtn: "Selesai & Analisis",
    analyzing: "Z.A.H.R.A sedang menganalisis biomarker kinematik dan akustik...",
    resultsTitle: "Laporan Pemeriksaan",
    riskScore: "Skor Risiko",
    recommendation: "Rekomendasi",
    consultDoctor: "Segera konsultasikan ke dokter saraf."
  },
  [Language.AR]: {
    welcome: "مرحبًا بك في زهرة (Z.A.H.R.A)",
    tagline: "الفحص العصبي في متناول يدك.",
    startBtn: "بدء التقييم",
    instructionsTitle: "بروتوكول التقييم",

    step1Title: "التحضير",
    step1Body: "تأكد من وجود إضاءة جيدة. ضع الهاتف في مستوى العين ليكون وجهك ويداك مرئيين بوضوح.",

    step2Title: "00:00 - 00:05 : الاختبار الحركي",
    step2Body: "ارفع كلتا يديك. اضغط بإبهامك والسبابة معًا بسرعة وبشكل واسع.",

    step3Title: "00:05 - 00:10 : اختبار الكلام",
    step3Body: "توقف عن النقر وقل العبارة التالية بوضوح وبصوت عالٍ:",
    speechPhrase: "\"السماء صافية والشمس مشرقة اليوم.\"",

    recordBtn: "فهمت، ابدأ التسجيل",
    stopBtn: "إيقاف وتحليل",
    analyzing: "يقوم Z.A.H.R.A بتحليل المؤشرات الحيوية الحركية والصوتية...",
    resultsTitle: "تقرير التقييم",
    riskScore: "درجة الخطر",
    recommendation: "توصية",
    consultDoctor: "استشر طبيب أعصاب فورًا."
  }
};