import { GoogleGenAI } from "@google/genai";
import { AnalysisResult, Language } from "../types";

const SYSTEM_INSTRUCTION_TEXT = `
Identitas: Anda adalah Z.A.H.R.A (Zenith AI for Health & Recovery Analysis), asisten AI medis tingkat tinggi.
Tujuan Utama: Melakukan skrining dini penyakit degeneratif saraf (Parkinson & Stroke).

Protokol Analisis:
1. Analisis Video (Vision): Deteksi gerakan motorik halus (MDS-UPDRS). Fokus pada Finger Tapping, Hand Movements, Pronation-Supination. Identifikasi mikrotremor (4-6 Hz) dan asimetri wajah. Skor 0 (Normal) s/d 4 (Parah).
2. Analisis Suara (Acoustic): Deteksi Dysarthria, jitter, dan nada monoton. Abaikan aksen, fokus pada ritme patologis.
3. Penalaran: Bandingkan data visual dan audio.
`;

export const analyzeAssessment = async (
  videoBlob: Blob,
  language: Language
): Promise<AnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing. Please ensure process.env.API_KEY is set.");
  }

  // Ensure the blob is valid
  if (videoBlob.size < 1000) {
    throw new Error("Recording is too short or empty.");
  }

  const ai = new GoogleGenAI({ apiKey });

  // Convert Blob to Base64
  const base64Data = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(videoBlob);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g., "data:video/webm;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
  });

  // Clean MIME type (remove codecs parameters)
  const mimeType = (videoBlob.type || 'video/webm').split(';')[0];
  
  // Use gemini-1.5-flash for stability
  const modelId = 'gemini-1.5-flash'; 

  // construct a single strong prompt instead of using config params which can cause 400 errors
  const finalPrompt = `
  ${SYSTEM_INSTRUCTION_TEXT}

  TASK:
  Z.A.H.R.A, jalankan analisis terhadap file video/audio ini sesuai Panduan Teknis.
  Bahasa Output untuk 'summary' dan 'recommendation': ${language}.
  
  1. Analisis Kinematika: Identifikasi Finger Tapping/Hand Movements. Beri skor 0-4.
  2. Analisis Akustik: Evaluasi ritme/kejelasan (Dysarthria/Monotonitas).
  3. Penalaran Multimodal: Hubungkan temuan video dan audio.
  
  OUTPUT FORMAT:
  You MUST return a raw JSON object matching exactly this structure. Do not use Markdown code blocks.
  
  {
      "overall_risk_score": number (0-10),
      "status_color": "Green" | "Yellow" | "Red",
      "motoric_scores": {
          "finger_tapping": number (0-4),
          "hand_movements": number (0-4),
          "facial_symmetry": number (0-4),
          "tremor": number (0-4)
      },
      "acoustic_analysis": string (summary of voice analysis),
      "recommendation": string (actionable advice in ${language}),
      "summary": string (human readable summary in ${language})
  }
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      config: {
        // We use JSON mode but remove the strict schema object to avoid INVALID_ARGUMENT on some inputs
        responseMimeType: "application/json",
        temperature: 0.2,
      },
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: base64Data
              }
            },
            {
              text: finalPrompt
            }
          ]
        }
      ]
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    // Sometimes the model might wrap in ```json ... ``` despite mimeType, so we clean it
    const cleanText = text.replace(/```json|```/g, '').trim();
    
    const parsed = JSON.parse(cleanText) as AnalysisResult;
    return parsed;

  } catch (error: any) {
    console.error("Gemini Analysis Error:", error);
    const errorMessage = error.message || "Unknown error";
    
    return {
      overall_risk_score: 0,
      status_color: 'Red',
      motoric_scores: { finger_tapping: 0, hand_movements: 0, facial_symmetry: 0, tremor: 0 },
      acoustic_analysis: "Analysis failed due to technical error.",
      recommendation: `System Error: ${errorMessage}. Please try again with a shorter recording or check your internet connection.`,
      summary: "An error occurred during AI processing."
    };
  }
};